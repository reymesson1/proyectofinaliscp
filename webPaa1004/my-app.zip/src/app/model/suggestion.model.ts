export class Suggestion{

  constructor(
    public id?: string, 
    public comments?: string, 
    public user?: string,    
  ){
  }
}