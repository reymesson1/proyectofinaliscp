import { Component,Injectable } from '@angular/core';
import { RestDataSource } from '../model/rest.datasource';

@Component({
  selector: 'delete-service',
  templateUrl: './delete-service.component.html',
  styleUrls: ['./delete-service.component.css']
})

@Injectable()
export class DeleteServiceComponent {

}